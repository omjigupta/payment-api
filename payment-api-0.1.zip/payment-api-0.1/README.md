# Money Transfer Api


# play-java-payment application v2.6 + H2 DB

This is a starter application that has base setup of Play 2.6 with H2 as database. This repository will constantly updated on better changes.

Please see the documentation at https://www.playframework.com/documentation/latest/Home for more details.

## Running

Run this using [sbt](http://www.scala-sbt.org/).  If you downloaded this project then you'll find a prepackaged version of sbt in the project directory:

```
sbt run
```

And then go to http://localhost:9000 to see the running web application.
